<?php
// Do not allow directly accessing this file.
if (!defined('ABSPATH')) {
    exit('Direct script access denied.');
}
?>
<div class="g5shop__archive-filter-content">
    <div class="container">
        <div class="row">
            <?php dynamic_sidebar('g5shop-filter'); ?>
        </div>
    </div>
</div>

