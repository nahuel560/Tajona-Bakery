<?php
G5ELEMENT()->load_file(G5ELEMENT()->plugin_dir('vc-customize/animation.php'));
G5ELEMENT()->load_file(G5ELEMENT()->plugin_dir('vc-customize/responsive.php'));
G5ELEMENT()->load_file(G5ELEMENT()->plugin_dir('vc-customize/custom-vc_row-overlay.php'));
G5ELEMENT()->load_file(G5ELEMENT()->plugin_dir('vc-customize/custom-vc_row-parallax.php'));
G5ELEMENT()->load_file(G5ELEMENT()->plugin_dir('vc-customize/custom-vc_toggle.php'));
G5ELEMENT()->load_file(G5ELEMENT()->plugin_dir('vc-customize/custom-vc_tta_accordions.php'));
G5ELEMENT()->load_file(G5ELEMENT()->plugin_dir('vc-customize/custom-vc_tta_tabs.php'));
G5ELEMENT()->load_file(G5ELEMENT()->plugin_dir('vc-customize/custom-vc_tta_section.php'));
G5ELEMENT()->load_file(G5ELEMENT()->plugin_dir('vc-customize/custom-vc_tta_tour.php'));
G5ELEMENT()->load_file(G5ELEMENT()->plugin_dir('vc-customize/custom-vc_progress_bar.php'));
G5ELEMENT()->load_file(G5ELEMENT()->plugin_dir('vc-customize/custom-vc_single_image.php'));
G5ELEMENT()->load_file(G5ELEMENT()->plugin_dir('vc-customize/custom-vc-icon.php'));

