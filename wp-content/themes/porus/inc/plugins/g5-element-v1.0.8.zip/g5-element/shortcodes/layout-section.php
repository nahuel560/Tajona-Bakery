<?php
/**
 * Element class
 */
if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly
}
class WPBakeryShortCode_G5Element_Layout_Section extends G5Element_ShortCode_Container {
}
